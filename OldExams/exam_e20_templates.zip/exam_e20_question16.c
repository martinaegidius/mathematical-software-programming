#include <math.h>

double geval(double x) { 
    /* Insert code here */
}
