#include <stdlib.h>
#include <math.h>

int darmv(int n, double * a, double * b, double * x) {
    /* Insert code here */
}
