#include <math.h>

double feval(double x) { 
    /* Insert code here */
}
