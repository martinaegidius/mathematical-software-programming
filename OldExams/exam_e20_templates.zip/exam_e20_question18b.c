#include <stdlib.h>
#include <math.h>

int darsv(int n, double * a, double * b, double * x) {
    /* Insert code here */
}
