#include <stdlib.h>
#include <math.h>

double weighted_harmonic_mean(int n, double * x, double * w) {
    /* Insert code here */
}