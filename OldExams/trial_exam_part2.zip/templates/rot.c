#include <stdlib.h>
#include <math.h>

int rot(double c, double s, int n, double * x, double * y){
  /* Insert code here */
}
