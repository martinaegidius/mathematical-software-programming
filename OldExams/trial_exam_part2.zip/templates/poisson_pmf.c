#include <stdlib.h>
#include <math.h>

double poisson_pmf(unsigned long k, double lambda) {
  /* Insert code here */
}
