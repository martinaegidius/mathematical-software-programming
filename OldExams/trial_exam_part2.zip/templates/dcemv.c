#include <stdlib.h>
#include <math.h>

int dcemv(int n, double * x) {
  /* Insert code here */
}
